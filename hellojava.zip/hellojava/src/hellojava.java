import java.net.SocketOption;
public class hellojava {
    public static void main(String[] args) {
        int age=10;
        if(age>9)
        {
            System.out.println("ahrcjgbk kh jk ");
        }
    }
}

package tech.codingclub;

public abstract class DummyCar extends Car {
public  abstract void move();

}

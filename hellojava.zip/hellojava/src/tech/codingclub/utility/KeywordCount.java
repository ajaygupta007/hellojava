package tech.codingclub.utility;

public class KeywordCount {
    public  String keyword;
    public int count;
    public KeywordCount()
    {

    }
    public KeywordCount(String keyword,int count)
    {
        this.keyword=keyword;
        this.count=count;
    }



}

package tech.codingclub;
public interface CarInterface {

    public static void printAboutWheel(){

    };

    public void applyBreak();
}

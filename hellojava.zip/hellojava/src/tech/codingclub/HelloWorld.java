package tech.codingclub;
import java.util.Date;

public class HelloWorld {
    public  static void main(String args[])
    {
       System.out.println("This is Ajay Gupta");
       System.out.println("Hello World running at "+ new Date().toString()+" sharp.");
    }

}

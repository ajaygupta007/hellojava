package tech.codingclub;
public class OopLearn {
    public static void main(String[] args) {
        LearnClass.main(null);
        ElectricCar.main(null);
    }
}

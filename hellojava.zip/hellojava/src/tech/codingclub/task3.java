package tech.codingclub;
import java.util.Date;

public class task3 {
    public static void main(String args[])
    {
       System.out.println("This is Ajay Gupta");
       System.out.println("task3 running at "+ new Date().toString()+" sharp.");
       byte a=1;
       short b=3;
       int c=5;
       long d=7;
       boolean e=true;
       char f='b';
       float g=9.0f;
       double h=11.0;
        System.out.println(a+":"+b+":"+c+":"+d+":"+e+":"+f+":"+":"+g+":"+h);
    }

}

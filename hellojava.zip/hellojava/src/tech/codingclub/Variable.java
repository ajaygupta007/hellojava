package tech.codingclub;
public class Variable {
    public static void main(String[] args) {
        task2.main(null);
        task3.main(null);
        task4.main(null);
    }
}

package tech.codingclub.entity;

public class Coders {
    private String name;
    private Long age;

    public String getName() {
        return name;
    }


    public Long getAge() {
        return age;
    }


    public Coders(String name, Long age) {
        this.name = name;
        this.age = age;
    }
    public Coders(){

    }
}

package tech.codingclub;

public class Ds2 {
    public static void main(String[] args) {
        SetExample.main(null);
        StackExample.main(null);
        SortExample.main(null);
    }
}

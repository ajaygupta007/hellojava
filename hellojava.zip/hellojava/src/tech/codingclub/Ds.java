package tech.codingclub;
public class Ds {
    public static void main(String[] args) {
        task7.main(null);
        task8.main(null);
        task9.main(null);
    }
}

import java.applet.Applet;
import java.awt.Graphics;
public class FirstApplet {
    public  void  paint(Graphics g)
    {
        g.drawString("HELLO ",150,150);
    }
}
